package com.herysson.userphoneapi.dto;

public record CreatePhoneDTO(String number) {}
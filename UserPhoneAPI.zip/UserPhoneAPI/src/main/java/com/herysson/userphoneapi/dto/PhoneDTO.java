package com.herysson.userphoneapi.dto;

public record PhoneDTO(Long id, String number) {}
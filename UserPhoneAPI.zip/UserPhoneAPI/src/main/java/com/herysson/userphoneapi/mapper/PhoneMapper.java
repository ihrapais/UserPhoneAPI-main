package com.herysson.userphoneapi.mapper;

import com.herysson.userphoneapi.dto.CreatePhoneDTO;
import com.herysson.userphoneapi.dto.PhoneDTO;
import com.herysson.userphoneapi.model.Phone;

public class PhoneMapper {
    public static PhoneDTO toDTO(Phone phone) {
        return new PhoneDTO(phone.getId(), phone.getNumber());
    }

    public static Phone toEntity(CreatePhoneDTO dto) {
        Phone phone = new Phone();
        phone.setNumber(dto.number());
        return phone;
    }
}
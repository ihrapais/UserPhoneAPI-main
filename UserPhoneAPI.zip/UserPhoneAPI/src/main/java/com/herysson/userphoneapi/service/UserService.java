package com.herysson.userphoneapi.service;

import com.herysson.userphoneapi.dto.CreateUserDTO;
import com.herysson.userphoneapi.dto.UserDTO;
import com.herysson.userphoneapi.mapper.UserMapper;
import com.herysson.userphoneapi.model.User;
import com.herysson.userphoneapi.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public UserDTO createUser(CreateUserDTO dto) {
        User user = UserMapper.toEntity(dto);
        User savedUser = userRepository.save(user);
        return UserMapper.toDTO(savedUser);
    }
}
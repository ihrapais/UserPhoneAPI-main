package com.herysson.userphoneapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserPhoneApiApplicationTests {

    @Test
    void contextLoads() {
    }

}

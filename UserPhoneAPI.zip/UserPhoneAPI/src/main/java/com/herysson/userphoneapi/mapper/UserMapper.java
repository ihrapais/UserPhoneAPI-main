package com.herysson.userphoneapi.mapper;

import com.herysson.userphoneapi.dto.CreateUserDTO;
import com.herysson.userphoneapi.dto.PhoneDTO;
import com.herysson.userphoneapi.dto.UserDTO;
import com.herysson.userphoneapi.model.Phone;
import com.herysson.userphoneapi.model.User;

import java.util.List;

public class UserMapper {
    public static UserDTO toDTO(User user) {
        List<PhoneDTO> phones = user.getPhones()
                .stream()
                .map(com.herysson.userphoneapi.mapper.PhoneMapper::toDTO)
                .toList();
        return new UserDTO(user.getId(), user.getName(), user.getEmail(), phones);
    }

    public static User toEntity(CreateUserDTO dto) {
        User user = new User();
        user.setName(dto.name());
        user.setEmail(dto.email());
        List<Phone> phones = dto.phones()
                .stream()
                .map(com.herysson.userphoneapi.mapper.PhoneMapper::toEntity)
                .peek(phone -> phone.setUser(user))
                .toList();
        user.setPhones(phones);
        return user;
    }
}